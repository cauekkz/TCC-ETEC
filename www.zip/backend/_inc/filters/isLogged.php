<?php
require_once __DIR__ . "/../jwt.php";

$jwt = new JwtAuth();
$tokenJWT = $jwt->get_jwt_by_header();

if ($tokenJWT) {
    $resultJWT = $jwt->validate_token($tokenJWT);
    if ($resultJWT) {
        // Token válido, continuar
        return;
    }
}

if (isset($_COOKIE["refreshToken"])) {
    $res->set_status('refresh');
    $res->set_error_message("need new JWT");
    $res->response();
    exit;
}

$res->set_status('Logg in');
$res->set_error_message("Logg in");
$res->response();
exit;
